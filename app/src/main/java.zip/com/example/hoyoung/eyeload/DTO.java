package kr.soen.mypart;

/**
 * Created by Jin on 2016-11-5.
 */

public abstract class DTO {
    private int key;
    abstract int getKey();
    abstract void setKey(int key);
}
