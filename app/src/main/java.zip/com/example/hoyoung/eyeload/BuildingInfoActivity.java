package kr.soen.mypart;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * Created by Jin on 2016-11-5.
 */

public class BuildingInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_building_info);
    }
    public void showBuildingInfo()
    {
        //Control의 getInfo()를 통해 Activity에 반환하거나 xml에 표시해줘야함
    }
}
