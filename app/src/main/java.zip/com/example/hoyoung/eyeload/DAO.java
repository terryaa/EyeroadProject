package kr.soen.mypart;

import java.util.ArrayList;
import java.util.Objects;

/**
 * Created by Jin on 2016-11-17.
 */

public abstract class DAO {
    //abstract boolean insert(Objects objects);
    //abstract boolean delete(Objects objects);
    //abstract DTO select(Objects objects);
    //abstract ArrayList<Objects> selectAll();
}
