package com.example.hoyoung.eyeload;

import java.util.List;

public abstract class DataSource {
    public abstract List<Marker> getMarkers();
}
